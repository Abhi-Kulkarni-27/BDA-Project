Basketball game data

Extension  meaning

Events American League teams (.EVA),
Events National League teams (.EVN), 
Events post-season games (.EVE).
Roster File  (.ROS)
